f="$CLAUDE_PROJECT_DIR/STATE.md"; [ -f "$f" ] && { echo "הפתק של הפרויקט (STATE.md), מהסשן הקודם. קרא אותו לפני שממשיכים:"; cat "$f"; }; exit 0
