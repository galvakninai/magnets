/**
 * HANDOFF Builder - הקמת גיליון הלידים של עסק שלך
 *
 * מה עושים עם הקובץ הזה:
 *   1. פותחים את הגיליון שאליו ייבאתם את HANDOFF_CRM.csv
 *   2. Extensions, ואז Apps Script
 *   3. מוחקים את מה שיש שם, מדביקים את כל הקובץ הזה, שומרים
 *   4. בוחרים למעלה את הפונקציה handoffSetup ולוחצים Run
 *   5. מאשרים את ההרשאה שגוגל מבקשת. היא נדרשת כדי לעצב את הגיליון שלכם
 *   6. חוזרים לגיליון. יופיע תפריט חדש בשם HANDOFF
 *
 * הערה על נוסחאות: לוח הבקרה נכתב בערכים ולא בנוסחאות, כדי שלא יישבר
 * בגיליון שהוגדר בשפה או באזור אחר.
 */

var SHEET_NAME = "לידים";
var DASH_NAME = "לוח בקרה";
var HEADERS = ["שם", "טלפון או IG", "מקור הפנייה", "מה הוא צריך", "שלב בתהליך", "סטטוס", "מועד פעולה הבא", "קישור לשיחה", "תאריך יצירה", "פעולה הבאה", "הערות"];
var STAGES = ["פנייה חדשה", "יצרנו קשר", "נשלחה הצעה", "סוכם"];
var STATUSES = ["דורש תגובה", "ממתין ללקוח", "פולואפ היום", "באיחור", "לא רלוונטי", "נסגר"];
var CHANNELS = ["Instagram DM", "WhatsApp", "טופס באתר", "הפניה מלקוח", "טלפון"];

var OPEN_STATUSES = ["דורש תגובה", "ממתין ללקוח", "פולואפ היום", "באיחור"];
var COL_SOURCE = 3;
var COL_STAGE = 5;
var COL_STATUS = 6;
var COL_NEXT = 7;

var COLOR_OVERDUE = "#f4cccc";
var COLOR_TODAY = "#fff2cc";
var COLOR_DONE = "#efefef";
var COLOR_HEADER = "#d9d9d9";

/**
 * צבע לכל סטטוס שנבחר ידנית, בתא הסטטוס בלבד, כדי שצבע השורה ימשיך
 * לומר דחיפות בזמן ולא ייבלע. המפה מוזרקת מ-STATUS_COLORS שב-build-deliverables.py,
 * אותו מקור שצובע את ה-xlsx, כדי ששני המסלולים לא יוכלו להיפרד שוב.
 * שני הסטטוסים המחושבים, פולואפ היום ובאיחור, לא נמצאים כאן. הם עולים מצבע השורה.
 */
var STATUS_COLORS = {"דורש תגובה": "#fce5cd", "ממתין ללקוח": "#cfe2f3", "נסגר": "#d9ead3", "לא רלוונטי": "#efefef"};

/** סדר העדיפות של צבעי הסטטוס, זהה לסדר הכללים ב-xlsx. */
var STATUS_COLOR_ORDER = ["דורש תגובה", "ממתין ללקוח", "לא רלוונטי", "נסגר"];

/** תפריט. שמות הפונקציות בתפריט לא נגמרים בקו תחתון, אחרת גוגל חוסמת אותן. */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("HANDOFF")
    .addItem("ליד חדש", "handoffNewLead")
    .addItem("סמן שנוצר קשר", "handoffMarkContacted")
    .addItem("דחה ביומיים", "handoffSnooze2")
    .addItem("רענן לוח בקרה", "handoffRefreshDashboard")
    .addToUi();
}

/** ההרצה החד פעמית. */
function handoffSetup() {
  var sheet = getDataSheet_();
  sheet.setName(SHEET_NAME);
  sheet.setRightToLeft(true);

  var header = sheet.getRange(1, 1, 1, HEADERS.length);
  header.setValues([HEADERS]);
  header.setFontWeight("bold");
  header.setBackground(COLOR_HEADER);
  sheet.setFrozenRows(1);

  for (var c = 1; c <= HEADERS.length; c++) {
    sheet.setColumnWidth(c, columnWidth_(HEADERS[c - 1]));
  }

  applyDropdown_(sheet, COL_SOURCE, CHANNELS);
  applyDropdown_(sheet, COL_STAGE, STAGES);
  applyDropdown_(sheet, COL_STATUS, STATUSES);
  applyColors_(sheet);

  handoffRefreshDashboard();
  SpreadsheetApp.getActive().toast("הגיליון מוכן. התפריט HANDOFF יופיע אחרי רענון הדף.");
}

function getDataSheet_() {
  var ss = SpreadsheetApp.getActive();
  var sheet = ss.getSheetByName(SHEET_NAME);
  if (sheet) { return sheet; }
  var sheets = ss.getSheets();
  for (var i = 0; i < sheets.length; i++) {
    if (sheets[i].getName() !== DASH_NAME) { return sheets[i]; }
  }
  return ss.insertSheet(SHEET_NAME);
}

function columnWidth_(name) {
  if (name === "מה הוא צריך" || name === "הערות" || name === "פעולה הבאה") { return 260; }
  if (name === "קישור לשיחה") { return 220; }
  return 130;
}

function applyDropdown_(sheet, column, values) {
  if (!column || !values || !values.length) { return; }
  var rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(values, true)
    .setAllowInvalid(false)
    .build();
  sheet.getRange(2, column, 500, 1).setDataValidation(rule);
}

/**
 * צביעה. הנוסחאות כאן נכתבות בתחביר האמריקאי, וזה מה ש-Apps Script מצפה לו
 * בכל שפה. גוגל מתרגמת אותן לתצוגה של המשתמש.
 */
function applyColors_(sheet) {
  var last = Math.max(sheet.getMaxColumns(), HEADERS.length);
  var range = sheet.getRange(2, 1, 500, last);
  var nextCol = colLetter_(COL_NEXT);
  var statusCol = colLetter_(COL_STATUS);
  var statusRange = sheet.getRange(2, COL_STATUS, 500, 1);
  var closed = '$' + statusCol + '2="' + STATUSES[5] + '"';
  var irrelevant = '$' + statusCol + '2="' + STATUSES[4] + '"';
  var open = 'NOT(OR(' + closed + ',' + irrelevant + '))';

  /**
   * הסדר הוא סדר העדיפות. ארבעת הראשונים צובעים את תא הסטטוס בלבד,
   * שלושת האחרונים צובעים את כל השורה. זהה אחד לאחד לסדר שב-xlsx:
   * אחרת הרצה כאן על גיליון שהומר מה-xlsx הייתה מוחקת את צבעי הסטטוס.
   */
  var rules = [];
  for (var i = 0; i < STATUS_COLOR_ORDER.length; i++) {
    var status = STATUS_COLOR_ORDER[i];
    rules.push(
      SpreadsheetApp.newConditionalFormatRule()
        .whenFormulaSatisfied('=$' + statusCol + '2="' + status + '"')
        .setBackground(STATUS_COLORS[status])
        .setRanges([statusRange])
        .build()
    );
  }

  rules.push(
    SpreadsheetApp.newConditionalFormatRule()
      .whenFormulaSatisfied('=OR(' + closed + ',' + irrelevant + ')')
      .setBackground(COLOR_DONE)
      .setRanges([range])
      .build(),
    SpreadsheetApp.newConditionalFormatRule()
      .whenFormulaSatisfied('=AND($' + nextCol + '2<>"",$' + nextCol + '2<TODAY(),' + open + ')')
      .setBackground(COLOR_OVERDUE)
      .setRanges([range])
      .build(),
    SpreadsheetApp.newConditionalFormatRule()
      .whenFormulaSatisfied('=AND($' + nextCol + '2=TODAY(),' + open + ')')
      .setBackground(COLOR_TODAY)
      .setRanges([range])
      .build()
  );

  sheet.setConditionalFormatRules(rules);
}

function colLetter_(index) {
  var letter = "";
  var n = index;
  while (n > 0) {
    var rem = (n - 1) % 26;
    letter = String.fromCharCode(65 + rem) + letter;
    n = Math.floor((n - 1) / 26);
  }
  return letter;
}

/** פעולות התפריט. */
function handoffNewLead() {
  var sheet = getDataSheet_();
  var row = sheet.getLastRow() + 1;
  var values = [];
  for (var i = 0; i < HEADERS.length; i++) { values.push(""); }
  values[COL_STAGE - 1] = STAGES[0];
  values[COL_STATUS - 1] = STATUSES[0];
  values[COL_NEXT - 1] = today_();
  sheet.getRange(row, 1, 1, HEADERS.length).setValues([values]);
  sheet.setActiveRange(sheet.getRange(row, 1));
}

function handoffMarkContacted() {
  var sheet = getDataSheet_();
  var row = sheet.getActiveRange().getRow();
  if (row < 2) { return; }
  sheet.getRange(row, COL_STATUS).setValue(STATUSES[1]);
  sheet.getRange(row, COL_NEXT).setValue(addDays_(today_(), 2));
  handoffRefreshDashboard();
}

function handoffSnooze2() {
  var sheet = getDataSheet_();
  var row = sheet.getActiveRange().getRow();
  if (row < 2) { return; }
  sheet.getRange(row, COL_NEXT).setValue(addDays_(today_(), 2));
  handoffRefreshDashboard();
}

function handoffRefreshDashboard() {
  var ss = SpreadsheetApp.getActive();
  var data = getDataSheet_();
  var dash = ss.getSheetByName(DASH_NAME) || ss.insertSheet(DASH_NAME);
  dash.setRightToLeft(true);

  var rows = [];
  if (data.getLastRow() > 1) {
    rows = data.getRange(2, 1, data.getLastRow() - 1, HEADERS.length).getValues();
  }
  var lines = computeDashboard_(rows, today_());
  dash.clear();
  dash.getRange(1, 1, lines.length, 2).setValues(lines);
  dash.getRange(1, 1, 1, 2).setFontWeight("bold");
  dash.setColumnWidth(1, 260);
  dash.setColumnWidth(2, 160);
}

/**
 * הליבה של לוח הבקרה, ופונקציה טהורה בכוונה: מקבלת שורות ותאריך, מחזירה טבלה.
 * ככה אפשר לבדוק אותה בלי גוגל.
 */
function computeDashboard_(rows, today) {
  var open = 0, needsReply = 0, overdue = 0, dueToday = 0, waiting = 0, closed = 0;
  var oldestName = "", oldestDate = null;

  for (var i = 0; i < rows.length; i++) {
    var row = rows[i];
    if (isEmptyRow_(row)) { continue; }
    var status = String(row[COL_STATUS - 1] || "").trim();
    var next = toDate_(row[COL_NEXT - 1]);
    var isOpen = OPEN_STATUSES.indexOf(status) !== -1;

    if (!isOpen) { closed++; continue; }
    open++;
    if (status === STATUSES[0]) { needsReply++; }
    if (status === STATUSES[1]) { waiting++; }
    if (next) {
      var diff = dayDiff_(next, today);
      if (diff < 0) {
        overdue++;
        if (!oldestDate || next < oldestDate) {
          oldestDate = next;
          oldestName = String(row[0] || "?");
        }
      } else if (diff === 0) {
        dueToday++;
      }
    }
  }

  var oldest = oldestDate ? oldestName + " (" + fmtDate_(oldestDate) + ")" : "אין";
  return [
    ["לוח בקרה", fmtDate_(today)],
    ["לידים פתוחים", open],
    ["דורש תגובה", needsReply],
    ["פולואפ היום", dueToday],
    ["באיחור", overdue],
    ["ממתין ללקוח", waiting],
    ["נסגרו או לא רלוונטיים", closed],
    ["הליד הכי ותיק באיחור", oldest]
  ];
}

function isEmptyRow_(row) {
  for (var i = 0; i < row.length; i++) {
    if (String(row[i] || "").trim() !== "") { return false; }
  }
  return true;
}

function toDate_(value) {
  if (!value && value !== 0) { return null; }
  if (Object.prototype.toString.call(value) === "[object Date]") {
    return new Date(value.getFullYear(), value.getMonth(), value.getDate());
  }
  var text = String(value).trim();
  var match = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (match) {
    return new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  }
  var parsed = new Date(text);
  if (isNaN(parsed.getTime())) { return null; }
  return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
}

function today_() {
  var now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

function addDays_(date, days) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days);
}

function dayDiff_(a, b) {
  return Math.round((a.getTime() - b.getTime()) / 86400000);
}

function fmtDate_(date) {
  var m = String(date.getMonth() + 1);
  var d = String(date.getDate());
  if (m.length < 2) { m = "0" + m; }
  if (d.length < 2) { d = "0" + d; }
  return date.getFullYear() + "-" + m + "-" + d;
}
