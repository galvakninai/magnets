# hebrew-landing

סקיל ל-Claude Code שבונה דף נחיתה בעברית: קובץ HTML אחד, RTL תקין, טופס מיילים עובד.

## התקנה

```bash
npx skills@latest add <OWNER>/<REPO> --skill hebrew-landing
```

או ידנית: להעתיק את התיקייה הזאת אל `~/.claude/skills/hebrew-landing`.

## שימוש

בתוך Claude Code:

```
/hebrew-landing
```

הוא ישאל אתכם חמש שאלות, יראה לכם את הקופי לאישור, ואז יבנה את הדף.

## מה בפנים

| קובץ | מה יש בו |
|---|---|
| `SKILL.md` | התהליך: ראיון, קופי, בנייה, חיווט, אימות |
| `references/structure.md` | תשעת חלקי הדף לפי הסדר, ולמה כל אחד יושב איפה שהוא יושב |
| `references/rtl-rules.md` | הבאגים של עברית RTL, ואיך מונעים כל אחד מהם |
| `references/form.md` | טופס עובד: honeypot, הסכמה, מצבי שגיאה, מצב הצלחה |
| `references/checklist.md` | מה בודקים לפני שמעלים לאוויר |
| `checklist/rtl-checklist.pdf` | **הצ׳קליסט להדפסה.** עמוד אחד לתלות ליד המסך |
| `example/index.html` | דף נחיתה שלם שנבנה בתהליך הזה. נקודת הקצה מנוטרלת בכוונה |

## דרישות

Claude Code מותקן. הוא רץ עם מנוי Claude בתשלום או עם חשבון Anthropic Console.

## הערה אחת

הסקיל לא ימציא לכם הוכחות. אם אין לכם עדיין מספרים או לקוחות, הוא יבנה דף בלי סעיף
הוכחות ויגיד לכם את זה. זה מכוון.

גל · vaknin.ai
