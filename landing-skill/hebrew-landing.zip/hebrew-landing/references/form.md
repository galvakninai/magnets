# The form

Copy this. It is the part that most generated landing pages get wrong, and the failures are
silent: the address looks collected and never arrives anywhere.

## Markup

```html
<form id="lead" novalidate>
  <label for="email">המייל שלכם</label>
  <input id="email" name="email" type="email" dir="ltr" inputmode="email"
         autocomplete="email" placeholder="name@example.com" required>

  <!-- honeypot: hidden from people, reachable by bots.
       never display:none, some bots skip those. never let it widen the page. -->
  <div class="hp" aria-hidden="true">
    <label for="company">Company</label>
    <input id="company" name="company" type="text" tabindex="-1" autocomplete="off">
  </div>

  <label class="consent" id="consent-label" for="consent">
    <input id="consent" type="checkbox">
    <span>אני מאשר/ת לקבל מיילים. אפשר להסיר בכל רגע.</span>
  </label>

  <button type="submit" id="submit">שלחו לי ←</button>
  <p id="msg" role="status" aria-live="polite"></p>
</form>

<div id="done" hidden>
  <h3>נשלח. תבדקו את המייל.</h3>
  <p>אם הוא לא הגיע תוך דקה, תבדקו בקידומי מבצעים.</p>
</div>
```

```css
.hp { position: absolute; width: 1px; height: 1px; overflow: hidden;
      clip-path: inset(50%); white-space: nowrap; }
```

`clip-path: inset(50%)` hides it visually without `display:none` and without adding a pixel
to the page width. Do not use a negative `left` offset: on an RTL page that is exactly what
creates horizontal scroll.

## Behaviour

```js
const ENDPOINT = "REPLACE_WITH_YOUR_ENDPOINT";
const form = document.getElementById('lead');
const msg  = document.getElementById('msg');
const btn  = document.getElementById('submit');
const ok   = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

form.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const email   = form.email.value.trim();
  const consent = document.getElementById('consent').checked;
  msg.textContent = '';

  if (!ok(email))   { msg.textContent = 'אנא הזינו כתובת מייל תקינה.'; form.email.focus(); return; }
  if (!consent)     { msg.textContent = 'כדי לקבל את הקובץ, יש לאשר קבלת מיילים.'; return; }

  btn.disabled = true; btn.textContent = 'שולח...';
  try {
    const r = await fetch(ENDPOINT, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, consent: true, company: form.company.value }),
    });
    if (!r.ok) throw new Error(r.status);
    form.hidden = true; document.getElementById('done').hidden = false;
  } catch (e) {
    btn.disabled = false; btn.textContent = 'שלחו לי ←';
    msg.textContent = 'אופס, משהו השתבש. נסו שוב בעוד רגע.';
  }
});
```

## Three things that are not optional

**The consent checkbox.** Adding someone to a marketing list without recorded consent is
illegal in Israel (amendment 40 to the Communications Law) and in the EU. Store the exact
wording the person agreed to, and the date, on the server side. Wording you changed later
is not proof of what they agreed to.

**The failure path.** If the request fails and you do nothing, the visitor sees a dead
button and leaves. Re-enable the button and say something.

**A local test before you ship.** Point `ENDPOINT` at a local server that logs the body, and
submit once. Read the logged payload. This catches the field-name typo that silently drops
every signup, which is the most expensive bug on this page and the least visible.

## Where addresses can go

- An email service (Mailchimp, Brevo, Kit, MailerLite): they host the form endpoint and send
  the deliverable. Easiest, and the deliverable actually gets sent.
- Your own endpoint (a serverless function): full control, you send the email yourself.
- A database row with no sending attached: collects addresses but **delivers nothing**. If
  you go this route, the page must hand over the file on screen, otherwise you promised
  something and sent nothing.
