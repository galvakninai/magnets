# Pre-ship checklist

Run every line. "It looks fine" is not a line.

## Render
- [ ] Screenshot at 390x844 and at 1440x900, and **open the screenshots and look at them**.
- [ ] No horizontal scroll at 360px wide. Check `documentElement.scrollWidth` against `clientWidth`.
- [ ] The first call to action is reachable on a phone without a real scroll.
- [ ] Hebrew renders correctly: no mojibake, no reversed punctuation, no clipped descenders.

## RTL
- [ ] `<html lang="he" dir="rtl">` and `<meta charset="utf-8">` are present.
- [ ] Every Latin run inside Hebrew text is wrapped in `<bdi>`.
- [ ] Email input, versions and URLs are `dir="ltr"`.
- [ ] Arrows that mean "forward" point left.
- [ ] Plain hyphens only. No em dashes, no en dashes.

## Form
- [ ] Invalid address is blocked and shows a Hebrew error.
- [ ] Unchecked consent is blocked and shows a Hebrew error.
- [ ] A valid submit posts the payload you expect. Prove it against a local server, not the live one.
- [ ] A server error re-enables the button and shows a message, instead of silently swallowing it.
- [ ] The success state replaces the form in place.
- [ ] The honeypot field is hidden from people but reachable by bots, and does not cause horizontal overflow.

## Accessibility
- [ ] Body text contrast is at least 4.5:1. Measure it, do not eyeball it.
- [ ] Every input has a real `<label>` tied to it.
- [ ] Keyboard only: you can reach the field, the checkbox and the button, and the focus ring is visible.
- [ ] `prefers-reduced-motion: reduce` turns the animation off.

## Content
- [ ] Every claim on the page is true and you can name the source.
- [ ] Zero invented numbers, testimonials, logos or reviews.
- [ ] The deliverable is named the same way everywhere.
- [ ] One action on the page. Competing links live in the success state.

## Ship
- [ ] The file opens correctly straight from `file://`, with no build step.
- [ ] `<title>` and `<meta name="description">` are set and in Hebrew.
- [ ] A link to a privacy page exists if you collect addresses.
