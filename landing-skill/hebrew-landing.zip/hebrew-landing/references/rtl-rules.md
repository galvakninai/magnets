# RTL rules for a Hebrew landing page

These are the bugs that give away a page that was built left-to-right and flipped.
Every one of them is invisible to someone who does not read Hebrew.

## The two lines that must be there

```html
<html lang="he" dir="rtl">
<meta charset="utf-8">
```

Without `charset` you get mojibake. Without `dir="rtl"` on the root element, punctuation at
the end of a sentence jumps to the wrong side, and lists and form fields align wrong.

## Latin text inside Hebrew text

Hebrew and Latin are opposite directions, so the browser has to guess where one ends and the
other begins. It guesses wrong at the boundaries, especially around punctuation.

```html
<!-- wrong: the dot can end up on the wrong side of the word -->
<p>הסקיל הזה רץ על Claude Code.</p>

<!-- right -->
<p>הסקיל הזה רץ על <bdi>Claude Code</bdi>.</p>
```

Rule: a Latin run inside a Hebrew sentence gets wrapped in `<bdi>` **when it stands on its
own**, with a space on both sides. Product names, file extensions, `RTL`, `HTML`, `PDF`.

## The exception that will bite you: a Hebrew prefix glued to a Latin word

Hebrew attaches single-letter prefixes with a hyphen: `ב-AI`, `מ-vaknin.ai`, `ל-Claude Code`,
`ה-RTL`. **Do not wrap the Latin part in `<bdi>` here, and do not force `white-space: nowrap`
on the pair.** Both create a bidi isolate boundary in the middle of what the reader sees as
one word, and the browser renders a visible double-width gap after it, or pushes the pair to
the start of the next line where it reads as a fragment.

```html
<!-- renders with a visible gap, and breaks badly at the end of a line -->
אתם רוצים להשתמש <span style="white-space:nowrap">ב-<bdi>AI</bdi></span> בעבודה.

<!-- correct: let the bidi algorithm do its job -->
אתם רוצים להשתמש ב-AI בעבודה.
```

This one is only visible in a render. The markup with `<bdi>` looks more careful and is
wrong. Screenshot the paragraph and read it before you believe it.

## Numbers, versions, emails and URLs

Digits are neutral, so a version number or a phone number can reverse.

```html
<span dir="ltr">v2.1.0</span>
<span dir="ltr">name@example.com</span>
<input type="email" dir="ltr" placeholder="name@example.com">
```

The email input in particular: leave it `dir="ltr"` so the address types left to right
while the label above it stays Hebrew.

## Direction of motion

In Hebrew, forward is to the **left**.

- A "next" or "continue" arrow points left: use the arrow that points left, not right.
- A progress bar fills from right to left.
- A carousel advances leftward.

Getting this backwards is the single most common tell.

## Logical properties beat physical ones

Use `margin-inline-start` instead of `margin-left`, `padding-inline-end` instead of
`padding-right`, `inset-inline-start` instead of `left`. They flip automatically with
direction, so the same stylesheet works if you ever ship an English version.

## The wordmark

A Latin brand name stays left-to-right even on an RTL page:

```html
<span dir="ltr" class="wordmark">brand<span class="dot">.ai</span></span>
```

## Fonts

Pick a font with real Hebrew coverage and real weights. Heebo, Assistant, Rubik and Noto
Sans Hebrew all work. A font without Hebrew falls back silently and the page looks cheap
without any error telling you why.

Hebrew has no capital letters, so you lose one level of typographic hierarchy that English
gets for free. Compensate with size and weight contrast, not with letter-spacing. Wide
letter-spacing on Hebrew looks broken, not elegant.

## Punctuation

Use a plain hyphen. Em dashes and en dashes sit badly in Hebrew RTL text and frequently
render on the wrong side of the phrase.

## Verify, do not assume

Screenshot the page and look at it. Every rule here fails silently: nothing throws, nothing
warns, the layout just quietly reads wrong to a Hebrew speaker.
