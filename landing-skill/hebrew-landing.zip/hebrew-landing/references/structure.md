# The nine sections, in order

Write them in this order. The order is the point: each section answers the objection the
previous one just created.

## 1. Hook
The reader's problem or the outcome they want. Not your product name, not your company.
Two short lines beat one long one. If you can only keep one sentence on the whole page,
keep this one.

Test: read it out loud to someone who has never heard of you. If their reaction is "so
what", it is about you and not about them.

## 2. Sub
One breath that answers three things: who you are, how it works, what they get.
This is where the mechanism goes. "A skill for Claude Code that asks you five questions and
returns one HTML file" is a mechanism. "Powered by AI" is not.

## 3. First call to action
The form, high on the page. On a phone it should be reachable without a real scroll.
Under the button, one line that removes the last hesitation: what it costs, how to get out.

Do not put a second competing link near it. Not your Instagram, not your other product.

## 4. What they get
Between three and five items. Each one concrete enough that the reader can picture the file.
"The RTL rules that stop the bugs" is an item. "Best practices" is not.

If you cannot list five real things, list three. Padding the list with filler is visible.

## 5. Who you are
First person, short. Why you are the person saying this. One real detail beats three
adjectives. A specific thing you built beats "passionate about technology".

## 6. Proof
Only if it is real. Screenshots of real work, real counts of real things, real names with
permission.

If there is no proof yet, the honest substitutes are: the page itself as a demonstration of
the craft you are selling, or a body of work the reader can go open right now. Both are
true statements. An invented testimonial is not, and it is the fastest way to lose the
reader who checks.

## 7. Who this is for, and who it is not for
Two short lists. The "not for" list is what makes the "for" list believable, and it filters
out the people who would have unsubscribed anyway.

Be specific enough to exclude someone. A "not for" list that excludes nobody is decoration.

## 8. Objections
The four questions a real person asks before typing their address. Usually:
- Am I the right person for this? (skill level, prerequisites)
- What does it cost me, really? (money, time, spam)
- What exactly arrives?
- What do you do with my details?

Answer them plainly. If the honest answer contains a requirement the reader will not like,
put it here rather than let them discover it later. Something they find out for themselves
after signing up costs you the relationship.

## 9. Closing call to action
The same form, the same button wording. Someone who read the whole page should not have to
scroll back up.

## After the form, not before
Anything that sends the visitor somewhere else belongs in the success state: follow links,
other products, your other channels. They have already done the one thing you asked.
