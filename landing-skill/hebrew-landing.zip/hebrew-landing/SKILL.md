---
name: hebrew-landing
description: Build a complete, production-ready Hebrew RTL landing page as one self-contained HTML file. Use when the user wants a landing page, a lead-capture page, a "link in bio" page, a waitlist page or a one-pager in Hebrew. Interviews the user, writes the copy in a converting direct-response structure, builds the page, and verifies it before handing it over.
---

# Hebrew Landing Page

Build one self-contained HTML file: a Hebrew, right-to-left landing page whose job is to
convert a visitor into one action, almost always an email address.

This skill is opinionated on purpose. The structure below is not a menu of ideas, it is the
order the page gets written in.

## Step 1: Interview. Five questions, one at a time.

Ask them in Hebrew, one per message, and wait for each answer. Do not batch them, and do
not start writing until all five are answered.

1. מה אתם מוכרים או מציעים, במשפט אחד?
2. למי זה מיועד, ולמי זה בפירוש לא?
3. מה הקורא מקבל ברגע שהוא משאיר פרטים?
4. מה ההוכחה האמיתית שיש לכם? (מספרים אמיתיים, עבודות קיימות, לקוחות. אם אין, אומרים שאין)
5. לאן נשלחים הפרטים? (שירות דיוור, טופס, או "עדיין לא יודע")

**If the answer to 4 is "there is none", say so plainly and build the page without a proof
section.** Never invent a number, a testimonial, a logo or a review. A page that invents
proof is worse than a page with none: the first person who checks stops trusting everything
else on it.

## Step 2: Write the copy before you write any CSS

Write the full copy as plain text and show it for approval. The structure, in this order:

1. **Hook** - the reader's problem or the outcome, not your product name.
2. **Sub** - who you are, the mechanism, and what they get. One breath.
3. **First call to action** - the form, high on the page, above the fold on a phone.
4. **What they get** - itemized and concrete. Five items maximum.
5. **Who you are** - first person, short, human.
6. **Proof** - only if it is real.
7. **Who this is for, and who it is not for** - the "not for" list is what makes the rest credible.
8. **Objections** - the four questions a real person would ask before typing their address.
9. **Closing call to action** - the same form, same wording.

Rules that decide whether it converts:
- One action per page. A second competing link belongs after the form, not before it.
- Every section earns its place or gets deleted.
- Say the deliverable by name every time. Not "the package", but "the prompt pack".
- No fake scarcity, no countdown that resets, no "only 3 spots left" unless there are.

Read `references/structure.md` for the full section-by-section guidance.

## Step 3: Build

One file. Inline CSS and JS. The only external dependency allowed is a web font.

**Read `references/rtl-rules.md` before writing markup.** Hebrew RTL is where these pages
break, and the breakage is invisible to someone who does not read Hebrew.

Design direction: ask what the brand feels like, then commit to one direction and carry it
through. Avoid the defaults that make a page look generated: gradient backgrounds behind
everything, glass cards, a row of identical icon tiles, emoji as decoration, six different
font sizes with no hierarchy.

## Step 4: Wire the form

Use `references/form.md`. It ships a working form with:
- a hidden honeypot field that catches bots,
- a required consent checkbox, because collecting marketing emails without recorded consent
  is illegal in most places, Israel included,
- visible error states for an invalid address, missing consent, and a server failure,
- a success state that replaces the form in place.

The form posts to whatever endpoint the user gave in question 5. If they said "I do not
know yet", leave `ENDPOINT` as a clearly marked placeholder and tell them exactly which
line to change.

## Step 5: Verify before you hand it over

Never say the page is done without running `references/checklist.md`
(`checklist/rtl-checklist.pdf` is the same list as a one-page sheet you can print). At minimum:
screenshot it at 390px and at 1440px and actually look at the screenshots, confirm there is
no horizontal scroll at 360px, and submit the form once against a local server to prove it
posts what you think it posts.

## The worked example

`example/index.html` is a complete, real landing page built with exactly this process. Its
endpoint is deliberately neutralised, so it cannot post anywhere until you point it at your
own. Open it, read it, take what you need. It is the reference for what "done" looks like:
the nine sections in order, the RTL handling, the form with its three failure states, and
the motion done in CSS so the page still renders with JavaScript switched off.

## Anti-patterns

- Writing CSS before the copy is approved.
- A hero that describes the product instead of the reader's problem.
- Inventing proof.
- Latin words bleeding into the wrong place in a Hebrew sentence because nothing was wrapped in `<bdi>`.
- Declaring it finished without opening a screenshot.
